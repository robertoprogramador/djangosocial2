from django.urls import path

from . import views
from django.conf import settings
from django.conf.urls.static import static

app_name = "credenciados"


urlpatterns = [
    path("", views.CredenciadoListview.as_view(), name="list"),
    path("<slug:slug>/", views.CredenciadoDetailview.as_view(), name="detail"),
     ]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
##27062022 acrescentando as views e forma paraINCLUIR ATUALIZAR E DELETAR
urlpatterns += [
    path('credenciado/create/', views.CredenciadoCreate.as_view(), name='credenciado_create'),
    path('credenciado/<int:pk>/update/', views.CredenciadoUpdate.as_view(), name='credenciado_update'),
    path('credenciado/<int:pk>/delete/', views.CredenciadoDelete.as_view(), name='credenciado_delete'),
]

