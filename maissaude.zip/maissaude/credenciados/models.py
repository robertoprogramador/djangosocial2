from django.contrib.auth.models import User
from django.db import models
from django.urls import reverse

# Create your models here.
class Credenciado(models.Model):
    medico = models.CharField(max_length=100)
    slug = models.SlugField(max_length=100, unique=True, default=0)
    foto = models.ImageField(upload_to='media',blank=True)
    especialidade = models.CharField(max_length=100)
    fonezap = models.CharField(max_length=100)
    endereço = models.CharField(max_length=100)
    bairro = models.CharField(max_length=100)
    cidade = models.CharField(max_length=100)
    estado = models.CharField(max_length=2)
#este codigo e para nao aparecer object1, object2 na listagem da page admin
    def __str__(self):
        return self.medico

#este codigo def captura o nome do objeto na list e abre a pagina detail do objeto
    def get_absolute_url(self):
        return reverse("credenciados:detail", kwargs={"slug": self.slug})
#esta class meta ordena a listagem por especialidade
    class Meta:
        ordering = ("especialidade",)