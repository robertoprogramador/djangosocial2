from django.apps import AppConfig


class CredenciadosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'credenciados'
