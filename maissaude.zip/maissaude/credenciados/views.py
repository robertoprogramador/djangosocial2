
from django.views.generic import DetailView,ListView

from .models import Credenciado

# Create your views here.
class CredenciadoListview(ListView):
    model = Credenciado
    #template_name="Credenciadoado_list.html"
    def get_queryset(self):
        return Credenciado.objects.order_by('cidade')
    
    def get_queryset(self):
        txt_nome = self.request.GET.get('cidade')
        txt_nome2 = self.request.GET.get('especialidade')
        
        
        if txt_nome and txt_nome2 :
            meufiltro = Credenciado.objects.filter(cidade=txt_nome, especialidade=txt_nome2)
           
            
        else:
            meufiltro = Credenciado.objects.all()

        return meufiltro
   

class CredenciadoDetailview(DetailView):
    model = Credenciado
    #template_name="Credenciadoado_detail.html" 

##NOVAS VIEWS PARA CADASTRARE ALTERAR ONLINE

from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

from credenciados.models import Credenciado

class CredenciadoCreate(CreateView):
    model = Credenciado
    fields = '__all__'
    #initial = {'date_of_death': '05/01/2018'}

class CredenciadoUpdate(UpdateView):
    model = Credenciado
    fields = ['medico', 'fonezap', 'endereço', 'especialidade']

class CredenciadoDelete(DeleteView):
    model = Credenciado
    success_url = reverse_lazy('Credenciados')

